package com.androidhive.googleplacesandmaps;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GridViewCustomAdapter extends ArrayAdapter
{
         Context context;
      
   

     public GridViewCustomAdapter(Context context)
     {
             super(context, 0);
             this.context=context;
            
     }
   
     public int getCount()
        {
                     return 22;
        }

     @Override
     public View getView(int position, View convertView, ViewGroup parent)
     {
             View row = convertView;
            
             if (row == null)
             {
                     LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                     row = inflater.inflate(R.layout.mygrid, parent, false);


                     TextView textViewTitle = (TextView) row.findViewById(R.id.textView);
                     ImageView imageViewIte = (ImageView) row.findViewById(R.id.imageView);
                    
                     if(position==0)
                     {
                         textViewTitle.setText("atm");
                         imageViewIte.setImageResource(R.drawable.atm);
                 }
                     if(position==1)
                     {
                         textViewTitle.setText("bakery");
                         imageViewIte.setImageResource(R.drawable.bakery);
                 }
                     if(position==2)
                     {
                         textViewTitle.setText("book store");
                         imageViewIte.setImageResource(R.drawable.book_store);
                 }
                     if(position==3)
                     {
                         textViewTitle.setText("bank");
                         imageViewIte.setImageResource(R.drawable.bank);
                 }
                     if(position==4)
                     {
                         textViewTitle.setText("cafe");
                         imageViewIte.setImageResource(R.drawable.cafe);
                 }
                     if(position==5)
                     {
                         textViewTitle.setText("garment shop");
                         imageViewIte.setImageResource(R.drawable.clothing_store);
                 }
                     if(position==6)
                     {
                         textViewTitle.setText("Doctor");
                         imageViewIte.setImageResource(R.drawable.doctor);
                 }
                     if(position==7)
                     {
                         textViewTitle.setText("Food");
                         imageViewIte.setImageResource(R.drawable.food);
                 }
                     
                     if(position==8)
                     {
                         textViewTitle.setText("Gym");
                         imageViewIte.setImageResource(R.drawable.gym);
                 }
                     if(position==9)
                     {
                         textViewTitle.setText("hardware");
                         imageViewIte.setImageResource(R.drawable.hardware_converted);
                 }
                     if(position==10)
                     {
                         textViewTitle.setText("Temple");
                         imageViewIte.setImageResource(R.drawable.hindu_temple);
                 }
                     if(position==11)
                     {
                         textViewTitle.setText("Hospital");
                         imageViewIte.setImageResource(R.drawable.hospita);
                 }
                     if(position==12)
                     {
                         textViewTitle.setText("Jwelery");
                         imageViewIte.setImageResource(R.drawable.jwelery_converted);
                 }
                     if(position==13)
                     {
                         textViewTitle.setText("mosque");
                         imageViewIte.setImageResource(R.drawable.mosque_converted);
                 }
                     if(position==14)
                     {
                         textViewTitle.setText("Theater");
                         imageViewIte.setImageResource(R.drawable.movie_theater);
                 }
                     if(position==15)
                     {
                         textViewTitle.setText("Parking");
                         imageViewIte.setImageResource(R.drawable.parking_area_converted);
                 }
                  
                     if(position==16)
                     {
                         textViewTitle.setText("Pharmacy");
                         imageViewIte.setImageResource(R.drawable.pharmacy_converted);
                 }
                     if(position==17)
                     {
                         textViewTitle.setText("Physio");
                         imageViewIte.setImageResource(R.drawable.physio_converted);
                 }
                     if(position==18)
                     {
                         textViewTitle.setText("Restaurant");
                         imageViewIte.setImageResource(R.drawable.restaurant_converted);
                 }
                     if(position==19)
                     {
                         textViewTitle.setText("School");
                         imageViewIte.setImageResource(R.drawable.school);
                 }
                     if(position==20)
                     {
                         textViewTitle.setText("Shoe store");
                         imageViewIte.setImageResource(R.drawable.shoe_store_converted);
                 }
                     if(position==21)
                     {
                         textViewTitle.setText("Shopping mall");
                         imageViewIte.setImageResource(R.drawable.shopping_mall_converted);
                 }
                  
        }


 
  return row;

 }

}