package com.androidhive.googleplacesandmaps;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
public class Menu extends Activity {

	GridView gridView;
	GridViewCustomAdapter grisViewCustomeAdapter;
	//	String var;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		
		gridView=(GridView)findViewById(R.id.gridViewCustom);
		 grisViewCustomeAdapter = new GridViewCustomAdapter(this);
		gridView.setAdapter(grisViewCustomeAdapter);
		//gridView.setNumColumns(3);
		
		
		gridView.setOnItemClickListener(new OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View v, int position, long arg3) {
                String selectedItem,var="atm";
                if(position==0)
                	var="atm";
                if(position==1)
                	var="bakery";
                if(position==2)
                	var="book_store";
                if(position==3)
                	var="bank";
                if(position==4)
                	var="cafe";
                if(position==5)
                	var="clothing_store";
                if(position==6)
                	var="doctor";
                if(position==7)
                	var="food";
                if(position==8)
                	var="gym";
                if(position==9)
                	var="hardware_store";
                if(position==10)
                	var="hindu_temple";
                if(position==11)
                	var="hospital";
                if(position==12)
                	var="jewelry_store";
                if(position==13)
                	var="mosque";
                if(position==14)
                	var="movie_theater";
                if(position==15)
                	var="parking";
                if(position==16)
                	var="pharmacy";
                if(position==17)
                	var="physiotherapist";
                if(position==18)
                	var="restaurant";
                if(position==19)
                	var="school";
                if(position==20)
                	var="shoe_store";
                if(position==21)
                	var="shopping_mall";
                
                
                
                startActivity(new Intent(Menu.this, MainActivity.class).putExtra("types", var));
              
            }
           });

	}

}
