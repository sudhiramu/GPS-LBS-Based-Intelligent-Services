package com.androidhive.googleplacesandmaps;

import java.io.Serializable;

import android.widget.Button;

import com.google.api.client.util.Key;
import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

/** Implement this class from "Serializable"
* So that you can pass this class Object to another using Intents
* Otherwise you can't pass to another actitivy
* */
public class PlaceDetails implements Serializable {
	
	//Button form;
	
	@Key
	public String status;
	
	@Key
	public Place result;

	
	@Override
	public String toString() {
		//form =(Button) findViewById(R.id.form);
		if (result!=null) {
			return result.toString();
		}
		return super.toString();
	}
	
}
